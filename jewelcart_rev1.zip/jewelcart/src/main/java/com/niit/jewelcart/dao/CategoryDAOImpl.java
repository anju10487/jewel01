package com.niit.jewelcart.dao;

public class CategoryDAOImpl 
{
	
	 public class CategoryDAOImpl implements CategoryDAO 
	{
		@Autowired
		private SessionFactory sessionFactory; 
		
		public CategoryDAOImpl(SessionFactory sessionFactory)
		{
			this.sessionFactory=sessionFactory;
		}
		
		
		@Transactional
		public void addCategory(Category category)
		{
			sessionFactory.getCurrentSession().saveOrUpdate(category);
		}
		
		@Transactional
		public void delete(String id)
		{
			Category category=new Category();
			category.setc_ID(id);
			sessionFactory.getCurrentSession().delete(category);
		}
		
		@Transactional
		public Category getCategory(String id)
		{
			String hql="from Category where c_ID="+"'"+id+"'";
			Query query=sessionFactory.getCurrentSession().createQuery(hql);
			List<Category> list=(List<Category>) query.list();
			if(list!=null&& !list.isEmpty())
			{
				return list.get(0);
			}
			return null;
			
		}
		
		@Transactional
		public Category getByName(String name)
		{
			String hql="from Category where c_Name="+"'"+ name +"'";
			@SuppressWarnings("rawtypes")
			Query query=sessionFactory.getCurrentSession().createQuery(hql);
			@SuppressWarnings("unchecked")
			List<Category> list= query.list();
			if(list!=null && !list.isEmpty())
			{
				return list.get(0);
			}
			return null;
			
		}
		
		@Transactional
		public List<Category> list()
		{
			List<Category> list= (List<Category>) sessionFactory.getCurrentSession().createCriteria(Category.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
			return list;
					
		}
	}
}
