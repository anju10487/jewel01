package com.niit.jewelcart.model;

public class User {

}
