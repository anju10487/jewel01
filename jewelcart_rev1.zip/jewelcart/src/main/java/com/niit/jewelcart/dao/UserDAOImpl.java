package com.niit.jewelcart.dao;

@Repository("userDAO")
@EnableTransactionManagement
public class UserDAOImpl implements UserDAO 
{
	
		@Autowired
		private SessionFactory sessionfactory;
			
			
			
			public UserDAOImpl(SessionFactory sessionfactory) 
			{
				
				this.sessionfactory = sessionfactory;
			}


		    @Transactional
			public void addUser(User user)
			{
				sessionfactory.getCurrentSession().saveOrUpdate(user);
			}
	
	}
}
